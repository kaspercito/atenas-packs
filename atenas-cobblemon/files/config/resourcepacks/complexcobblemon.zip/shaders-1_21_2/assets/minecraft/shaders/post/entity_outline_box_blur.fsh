#version 150

uniform sampler2D InSampler;
uniform vec2 BlurDir;

in vec2 texCoord;
in vec2 sampleStep;

out vec4 fragColor;

const vec4 BLOCK_OUTLINE_COLOR = vec4(1.0, 0.0, 0.0, 1.0);

void main() {
    vec4 color = texture(InSampler, texCoord);
    vec4 detectColor = texelFetch(InSampler, ivec2(0), 0);
    bool isHighlight = abs(detectColor.a - 0.69420) < 0.1;
    bool isBlockMarker = color.a < 0.2;

    //we must not blur waypoint markers
    if (abs(color.a - 0.42069) < 0.1) {
        fragColor = color;

        //last pass of blur
        if (BlurDir.y == 1.0) {
            fragColor.a = 1.0;
        }

        return;
    }

    if (isHighlight && !isBlockMarker) {
        fragColor = texture(InSampler, texCoord);
        return;
    }

    vec4 blurred = vec4(0.0);
    float radius = 2.0;

    for (float a = -radius + 0.5; a <= radius; a += 2.0) {
        blurred += texture(InSampler, texCoord + sampleStep * a);
    }

    blurred += texture(InSampler, texCoord + sampleStep * radius) / 2.0;
    fragColor = vec4((blurred / (radius + 0.5)).rgb, blurred.a);

    if (isHighlight && isBlockMarker && fragColor.a > 0.0) {
        fragColor = BLOCK_OUTLINE_COLOR;
    }
}
