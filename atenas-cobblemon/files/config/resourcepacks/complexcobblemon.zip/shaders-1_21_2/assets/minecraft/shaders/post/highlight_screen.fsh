#version 150

uniform sampler2D InSampler;
uniform vec4 ColorModulate;

in vec2 texCoord;
in vec2 oneTexel;

out vec4 fragColor;

void main() {
    vec4 color = texture(InSampler, texCoord) * ColorModulate;
    vec4 detectColor = texelFetch(InSampler, ivec2(0), 0);
    bool isHighlight = abs(detectColor.a - 0.69420) < 0.1;
    bool isBlockMarker = isHighlight && abs(color.a - 0.245) < 0.1;

    //markers
    if (abs(color.a - 0.42069) < 0.1) {
        fragColor = color;
        fragColor.a = 0.42069;
        return;
    }

    if (isHighlight && !isBlockMarker) {
        if (gl_FragCoord.x < 1 && gl_FragCoord.y < 1) {
            fragColor = color;
        } else {
            fragColor = vec4(0, 0, 0, 0.9);
        }

        return;
    }

    //vanilla
    vec4 center = texture(InSampler, texCoord);
    vec4 left = texture(InSampler, texCoord - vec2(oneTexel.x, 0.0));
    vec4 right = texture(InSampler, texCoord + vec2(oneTexel.x, 0.0));
    vec4 up = texture(InSampler, texCoord - vec2(0.0, oneTexel.y));
    vec4 down = texture(InSampler, texCoord + vec2(0.0, oneTexel.y));

    if (isBlockMarker) {
        center.a = 1.0;
        left.a = 1.0;
        right.a = 1.0;
        up.a = 1.0;
        down.a = 1.0;
    }

    float leftDiff  = abs(center.a - left.a);
    float rightDiff = abs(center.a - right.a);
    float upDiff    = abs(center.a - up.a);
    float downDiff  = abs(center.a - down.a);
    float total = clamp(leftDiff + rightDiff + upDiff + downDiff, 0.0, 1.0);
    vec3 outColor = center.rgb * center.a + left.rgb * left.a + right.rgb * right.a + up.rgb * up.a + down.rgb * down.a;

    fragColor = vec4(outColor * 0.2, total);
}
