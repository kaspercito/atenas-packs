#version 150
#define FSH
#define RENDERTYPE_TEXT
#moj_import <fog.glsl>

// These are inputs and outputs to the shader
// If you are merging with a shader, put any inputs and outputs that they have, but are not here already, in the list below

uniform sampler2D Sampler0;

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;
uniform float GameTime;
uniform vec2 ScreenSize;
in float vertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec4 baseColor;
in vec4 lightColor;

out vec4 fragColor;
const vec2 textureSize = vec2(256, 256);
const vec2 oneTexel = 1./textureSize;

#define SHADOW 0.248
#define ONE_MINUS_EPS 0.999
#moj_import <spheya_packs_impl.glsl>

ivec3 getData(int x, int y) {
    return ivec3(texture(Sampler0, vec2(1)
        - vec2(x, y) * oneTexel
    ).rgb * 255.);
}

bool isRed(vec4 a) {
    return a.r == 0.988235294 && a.g == 0.329411765 && a.b == 0.329411765 && a.a == 1.0;
}

void main() {
    if(applySpheyaPacks()) return;

    // Code below here is vanilla rendering,
    // If you are merging with another shader, replace the code below here with the code that they have in their main() function


    ivec3 data2 = getData(3, 1);
    bool animateTopBottom = data2.r == 1 && data2.b == 253;



    ivec3 data0 = getData(1, 1);

    vec2 frameSize = vec2(data0.xy);
    bool isAnimated = data0.z == 253;

    // Position to read texture at
    vec2 uv = texCoord0;

    if (isAnimated) {
        vec2 texelFrame = frameSize * oneTexel;

        ivec3 data1 = getData(2, 1);

        float frameDuration = float(data1.x) * 0.1;
        bool showShadow = bool(data1.z & 1);
        float frameCount = float(data1.y);

        // Remove shadows following dragonmaster's method
        if (!showShadow && all(lessThan(
            vertexColor.rgb,
            vec3(SHADOW)
        ))) {
            discard;
        }

        // Scale down uv to be on first frame
        uv *= texelFrame;

        /* Squish uv to fit frame ratio.
         * The uv is moved to the top-left so that positioning can be corrected by
         * changing ascent or adding negative space afterwards.
         */
        float tfRatio = texelFrame.y/texelFrame.x;
        if (tfRatio > 1.0) {
            uv.x *= tfRatio;
        } else {
            uv.y /= tfRatio;
        }

        // Check if uv ends up outside of current frame
        if (
            uv.x > texelFrame.x || uv.y > texelFrame.y
        ) {
            discard;
        }

        // Shift uv to correct frame
        float frameID = mod(floor(GameTime * 24000. / frameDuration), frameCount);
        vec2 offsetAmount = texelFrame * (animateTopBottom ? vec2(
                        floor((frameID + ONE_MINUS_EPS) * texelFrame.y),
                        fract((frameID + ONE_MINUS_EPS) * texelFrame.y)/texelFrame.y - ONE_MINUS_EPS
                    ):vec2(
                    fract((frameID + ONE_MINUS_EPS) * texelFrame.x)/texelFrame.x - ONE_MINUS_EPS,
                    floor((frameID + ONE_MINUS_EPS) * texelFrame.x)
                ));
        uv += offsetAmount;
    }

    // Continue to read texture as normal, but with potentially changed uv
    vec4 color = texture(Sampler0, uv) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    
    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
    if(vertexDistance > 2020.0 && isRed(fragColor) && ScreenSize.x - gl_FragCoord.x < 52) {
        discard;
    }
}
